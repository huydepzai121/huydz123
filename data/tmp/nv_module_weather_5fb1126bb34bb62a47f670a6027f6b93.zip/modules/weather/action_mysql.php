<?php

/**
 * @Project Module Nukeviet 4.x
 * @Author Webvang.vn (hoang.nguyen@webvang.vn)
 * @copyright 2014 J&A.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @createdate 08/10/2014 09:47
 */
if (!defined('NV_IS_FILE_MODULES'))
    die('Stop!!!');

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data;
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_city";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_time_period";

$sql_create_module = $sql_drop_module;
$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . " (
    id mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
    id_city mediumint(8) NOT NULL,
    id_time_period mediumint(8) NOT NULL,
    date_forecast datetime NOT NULL,
    description varchar(255) NOT NULL,
    wind_speed int(11) NOT NULL,
    temperature_note varchar(255) NOT NULL,
    temperature_value float NOT NULL,
    weight tinyint(4) NOT NULL,
    avatar varchar(255) DEFAULT NULL,
    PRIMARY KEY (id)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_city (
    id mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
    name varchar(255) NOT NULL,
    ma_vung varchar(10) NOT NULL,
    quoc_gia varchar(255) NOT NULL,
    PRIMARY KEY (id)
) ENGINE=MyISAM;";
